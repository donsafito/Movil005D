import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { IonInput, IonTabs } from '@ionic/angular';
import { now } from '@ionic/core/dist/types/utils/helpers';
import { StorageService } from 'src/app/services/storage.service';
import { v4} from 'uuid';


@Component({
  selector: 'app-qr',
  templateUrl: './qr.page.html',
  styleUrls: ['./qr.page.scss'],
})
export class QrPage implements OnInit {
  rut: string;
  usuario: any;
  asignaturast: any[] = [];
  clases: any[] = [];
  datos: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  KEY_CLASES = 'clases';
  KEY_PERSONAS = 'personas';
  codigo = v4();
  listado: any[] = [];
  hoy : string = new Date().toDateString();
  //VARIABLES PARA CREAR NUESTRO CÓDIGO QR:
  elementType = 'canvas';
  value = '';

    dato = {
      id: '',
      id_asig: '',
      fecha: '',
      alumnos: []
    };

    constructor(private router: Router,private storage: StorageService, private activatedRoute: ActivatedRoute) { }

 async ngOnInit() {
    this.rut = this.activatedRoute.snapshot.paramMap.get('id');
    this.usuario = await this.storage.getDato(this.KEY_PERSONAS,this.rut);
    console.table(this.usuario);
    this.dato.id = await v4();
    await this.cargarDatos();
  }
  
  //métodos:
  async cargarDatos(){
    this.asignaturast = await this.storage.getDatos(this.KEY_ASIGNATURAS)
    this.clases = await this.storage.getDatos(this.KEY_CLASES)
    this.dato.fecha = this.hoy;
  }
  
  async agregarClase(){
    
    if ( await this.storage.validarFecha(this.KEY_CLASES,this.dato.id_asig,this.dato.fecha) != undefined) {
      alert('ya se registro esta clase el dia de hoy :(');
      return;
    } 

    if(this.dato.id_asig != ''){
      var registrada = await this.storage.agregarClase(this.KEY_CLASES, this.dato);
      this.value = this.dato.id
      if(registrada){
           alert('Clase creada correctamente');
           this.dato.id = (v4());
           this.dato.fecha = this.hoy;
           this.dato.alumnos = this.listado;
           await this.cargarDatos();
        }else{
        alert('No se pudo crear la clase.')
        }
      }else{
        alert('debe seleccionar un campo.')
        
      }
      }
}
