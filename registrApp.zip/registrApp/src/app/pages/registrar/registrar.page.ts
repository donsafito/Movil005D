import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-registrar',
  templateUrl: './registrar.page.html',
  styleUrls: ['./registrar.page.scss'],
})
export class RegistrarPage implements OnInit {

  //variable grupo:
  usuario = new FormGroup({
    id: new FormControl('', Validators.required),
    rut: new FormControl('', [Validators.required, Validators.pattern('[0-9]{1,2}.[0-9]{3}.[0-9]{3}-[0-9kK]')]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    ap_paterno: new FormControl('', [Validators.required, Validators.minLength(3)]),
    fecha_nac: new FormControl('', [Validators.required]),
    correo: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@(duoc|duocuc|profesor.duoc).(cl)')]),
    clave: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(18)]),
    tipo_usuario: new FormControl('alumno', [Validators.required]),
    semestre: new FormControl('', [Validators.required]),
  });
  repetir_clave: string;

  constructor(private usuarioService: UsuarioService, private validaciones: ValidacionesService, private router: Router, private storage: StorageService) { }
  usuarios: any[] = [];
  KEY_PERSONAS = 'personas';
  codigo = v4();
 async  ngOnInit() {
    this.usuario.controls.id.setValue(this.codigo);
    await this.cargarDatos();
  }
   //métodos:
  async cargarDatos(){
    this.usuarios = await this.storage.getDatos(this.KEY_PERSONAS);
  }
  //métodos:
  async registrar() {
    if (!this.validaciones.validarRut(this.usuario.controls.rut.value)) {
      alert('Rut incorrecto!');
      return;
    } 
      
     if (!this.validaciones.validarEdadMinima(17, this.usuario.controls.fecha_nac.value)) {
      alert('Edad mínima 17 años!');
      return ;
    }

    if (this.usuario.controls.clave.value != this.repetir_clave) {
      alert('Contraseñas no coinciden!');
      return ;
    }
    if(await this.storage.validarCorreo(this.KEY_PERSONAS,this.usuario.controls.correo.value) != undefined){
      alert('Este correo ya se encuentra registrado.')
      return ;
    }

    if(await this.storage.validarRut(this.KEY_PERSONAS,this.usuario.controls.rut.value) != undefined){
      alert('Este rut ya se encuentra registrado.')
      return ;
    }
     
     var registrado = await this.storage.agregar(this.KEY_PERSONAS, this.usuario.value);
    if(registrado){
      alert('Registrado Correctamente');
      await this.cargarDatos();
      this.usuario.controls.id.setValue(v4());
      this.repetir_clave = '';
      this.router.navigate(['/login']);
      this.usuario.reset();
      
    }else{
      alert('Usuario NO registrado')
    }
  }

}
