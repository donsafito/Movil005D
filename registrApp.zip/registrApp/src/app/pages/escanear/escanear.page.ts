import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-escanear',
  templateUrl: './escanear.page.html',
  styleUrls: ['./escanear.page.scss'],
})
export class EscanearPage implements OnInit {

  usuario: any = {};
  rut: string;
  id_clase: '';
  rutusar : string;
  asignaturast: any[] = [];
  clasest: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  KEY_CLASES = 'clases';
  KEY_PERSONAS = 'personas'
  hoy : string = new Date().toDateString();
  
    dato = {
    id_asignatura: ''
    };

  constructor(private router: Router, private storage: StorageService, private activatedRoute: ActivatedRoute) { }

  async ngOnInit() {
    this.rut = await this.activatedRoute.snapshot.paramMap.get('id');
    this.usuario = await this.storage.getDato(this.KEY_PERSONAS,this.rut);
    await this.cargarDatos();

  }

  async cargarDatos(){
    this.asignaturast = await this.storage.getDatos(this.KEY_ASIGNATURAS)
    this.clasest = await this.storage.getDatos(this.KEY_CLASES)
  }
  
  
  
  async registrarAsistencia(){
    
    var idEncontrado = await this.storage.getDato(this.KEY_CLASES,this.dato.id_asignatura);
      if(idEncontrado){
          if(idEncontrado.alumnos.includes(this.usuario.rut)){
            alert('Usted ya se encuentra presente');
          }else{
              await idEncontrado.alumnos.push(this.usuario.rut);
              await this.cargarDatos();
              await this.storage.actualizar(this.KEY_CLASES, idEncontrado);
             alert('Se registro correctamente su asistencia.');
          }
        }else{
      alert('No existe clase para registrar su asistencia')
    }
    
  }}