import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-asignaturas',
  templateUrl: './asignaturas.page.html',
  styleUrls: ['./asignaturas.page.scss'],
})
export class AsignaturasPage implements OnInit {
  //variable grupo:
  asignatura = new FormGroup({
    id: new FormControl('', Validators.required),
    sigla: new FormControl('', [Validators.required, Validators.minLength(3)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    docente: new FormControl('', [Validators.required]),
    cant_alumnos: new FormControl('', [Validators.required, Validators.min(5), Validators.max(40)]),
    escuela: new FormControl('', [Validators.required, Validators.minLength(3)])
  });
  

  KEY_PERSONAS = 'personas'
  personas: any[] = [];
  asignaturast: any[] = [];
  KEY_ASIGNATURAS = 'asignaturas';
  codigo = v4();
  constructor(private usuarioService: UsuarioService, private alertController: AlertController, private validaciones: ValidacionesService, private storage: StorageService) { }

  async ngOnInit() {
    this.asignatura.controls.id.setValue(this.codigo);
    await this.cargarDatos();
  }
  
   //métodos:
   async cargarDatos(){
    this.asignaturast = await this.storage.getDatos(this.KEY_ASIGNATURAS)
    this.personas = await this.storage.getDatos(this.KEY_PERSONAS);
  }

  async registrar() {
    
    this.asignatura.controls.id.setValue(v4());
     var registrado = await this.storage.agregarAsignatura(this.KEY_ASIGNATURAS, this.asignatura.value);
    if(registrado){
      alert('Registrada Correctamente');
      await this.cargarDatos();
      this.asignatura.reset();
    }else{
      alert('Asignatura no registrada.')
    }
  }

  async buscar(asignaturaBuscar) {
    var asignaturaEncontrada = await this.storage.getDato(this.KEY_ASIGNATURAS, asignaturaBuscar);
    this.asignatura.setValue(asignaturaEncontrada);
    
  }

  async eliminar(asignaturaEliminar) {
    const alert = await this.alertController.create({
      header: '¿Seguro que desea eliminar la asignatura ' + asignaturaEliminar + '?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('NO ELIMINA!');
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: async() => {
             await this.storage.eliminar(this.KEY_ASIGNATURAS, asignaturaEliminar);
             await this.cargarDatos();
          },
        },
      ],
    });
   
    
    await alert.present();
  }

  async modificar() {
   
    await this.storage.actualizar(this.KEY_ASIGNATURAS, this.asignatura.value);
    alert('Usuario modificado!');
    await this.cargarDatos();
    this.asignatura.reset();
  }

 

  //método para cerrar sesión:
  logout(){
    this.usuarioService.logout();
  }


}
