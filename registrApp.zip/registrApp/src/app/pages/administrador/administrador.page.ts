import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { StorageService } from 'src/app/services/storage.service';
import { UsuarioService } from 'src/app/services/usuario.service';
import { ValidacionesService } from 'src/app/services/validaciones.service';
import { v4 } from 'uuid';

@Component({
  selector: 'app-administrador',
  templateUrl: './administrador.page.html',
  styleUrls: ['./administrador.page.scss'],
})
export class AdministradorPage implements OnInit {

  //variable grupo:
  usuario = new FormGroup({
    id: new FormControl('', Validators.required),
    rut: new FormControl('', [Validators.required, Validators.pattern('[0-9]{1,2}.[0-9]{3}.[0-9]{3}-[0-9kK]')]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    ap_paterno: new FormControl('', [Validators.required, Validators.minLength(3)]),
    fecha_nac: new FormControl('', [Validators.required]),
    correo: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@(duoc|duocuc|profesor.duoc).(cl)')]),
    clave: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(18)]),
    tipo_usuario: new FormControl('', [Validators.required]),
    semestre: new FormControl('', [Validators.min(1), Validators.max(8)])
  });
  
  repetir_clave: string;
  usuarios: any[] = [];
  KEY_PERSONAS = 'personas';
  codigo = v4();
  constructor(private usuarioService: UsuarioService, private alertController: AlertController, private validaciones: ValidacionesService, private storage: StorageService) { }

  async ngOnInit() {
    this.usuario.controls.id.setValue(this.codigo);
    await this.cargarDatos();
  }
   
  //métodos:
  async cargarDatos(){
    this.usuarios = await this.storage.getDatos(this.KEY_PERSONAS)
  }

  async registrar() {
    if (!this.validaciones.validarRut(this.usuario.controls.rut.value)) {
      alert('Rut incorrecto!');
      return;
    } 
      
     if (!this.validaciones.validarEdadMinima(17, this.usuario.controls.fecha_nac.value)) {
      alert('Edad mínima 17 años!');
      return ;
    }

    if (this.usuario.controls.clave.value != this.repetir_clave) {
      alert('Contraseñas no coinciden!');
      return ;
    }

    if(await this.storage.validarCorreo(this.KEY_PERSONAS,this.usuario.controls.correo.value) != undefined){
      alert('Este correo ya se encuentra registrado.')
      return ;
    }

    if(await this.storage.validarRut(this.KEY_PERSONAS,this.usuario.controls.rut.value) != undefined){
      alert('Este rut ya se encuentra registrado.')
      return ;
    }
     
     var registrado = await this.storage.agregar(this.KEY_PERSONAS, this.usuario.value);
    if(registrado){
      alert('Registrado Correctamente');
      this.usuario.controls.id.setValue(v4());
      await this.cargarDatos();
      this.usuario.reset();
    }else{
      alert('Usuario NO registrado')
    }
  }

  async buscar(rutBuscar) {
    var usuarioEncontrado = await this.storage.getDato(this.KEY_PERSONAS, rutBuscar);
    this.usuario.setValue(usuarioEncontrado);
    this.repetir_clave = await  usuarioEncontrado.clave;
  }

  async eliminar(rutEliminar) {
    const alert = await this.alertController.create({
      header: '¿Seguro que desea eliminar al usuario de rut ' + rutEliminar + '?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('NO ELIMINA!');
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: async() => {
             await this.storage.eliminar(this.KEY_PERSONAS, rutEliminar);
             await this.cargarDatos();
          },
        },
      ],
    });
   
    
    await alert.present();
  }

  async modificar() {
   
    await this.storage.actualizar(this.KEY_PERSONAS, this.usuario.value);
    alert('Usuario modificado!');
    await this.cargarDatos();
    this.usuario.reset();
  }

 

  //método para cerrar sesión:
  logout(){
    this.usuarioService.logout();
  }

}
