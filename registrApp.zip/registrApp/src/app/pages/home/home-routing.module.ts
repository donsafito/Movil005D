import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: '',
    component: HomePage,
    children: [
      {
        path: 'administrador',
        loadChildren: () => import('../administrador/administrador.module').then(m => m.AdministradorPageModule)
      },
      {
        path: 'micuenta-alumno/:rut',
        loadChildren: () => import('../micuenta-alumno/micuenta-alumno.module').then( m => m.MicuentaAlumnoPageModule)
      },

      {
        path: 'micuenta/:rut',
        loadChildren: () => import('../micuenta/micuenta.module').then( m => m.MicuentaPageModule)
      }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule {}
